# Support

For LanGuard Pro support, use the Issues section of this public repository after it is published.

## Include

- LanGuard Pro version and version code
- Android version and device model
- Router model
- OpenWrt / ImmortalWrt version
- Whether the issue affects Android, LuCI, Companion, or all three
- Clear reproduction steps
- Sanitized screenshots or logs

## Do not include

- router passwords
- SSH private keys
- Wi-Fi passwords
- API tokens
- private recovery codes
- personally identifying information that is not needed for the report

For privacy information, see:

https://github.com/SAMZLAB-PK/LanGuard-Pro-Privacy
