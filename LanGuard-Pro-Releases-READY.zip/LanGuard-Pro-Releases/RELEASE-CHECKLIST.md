# LanGuard Pro release checklist

Use this checklist before publishing a Play Store or GitHub release.

- [ ] Increment `versionName` and `versionCode` intentionally.
- [ ] Confirm package remains `com.samz.languardpro`.
- [ ] Confirm `compileSdk` / `targetSdk` satisfy current Google Play requirements.
- [ ] Run unit tests and WebView regression tests.
- [ ] Run router source/payload validation.
- [ ] Run Android lint.
- [ ] Produce a clean release APK/AAB from the current source revision.
- [ ] Sign with the authorized production/upload identity only.
- [ ] Verify signing certificate before upload.
- [ ] Confirm no keystore, private key, password, token, or `local.properties` is included in source/release archives.
- [ ] Verify Companion and LuCI embedded payloads match canonical router sources.
- [ ] Test Home/Office router profile switching.
- [ ] Test live device speed on IPv4 and IPv6-capable devices.
- [ ] Test block/unblock, speed limit, priority, rename, and DHCP reservation.
- [ ] Test Companion and LuCI install/repair, including SSH trust-reset recovery after a known host-key change.
- [ ] Test foreground/background monitoring and notification behavior.
- [ ] Test speed test on a real router.
- [ ] Confirm Play Console foreground-service declaration remains accurate.
- [ ] Update `CHANGELOG.md` and `releases/<version>.md`.
- [ ] Publish Play Store release first or at the intended coordinated time.
- [ ] If publishing a GitHub APK, attach only the intentionally signed public APK and its SHA-256 checksum.
