# First-time repository setup

Create a new **Public** GitHub repository named:

`LanGuard-Pro-Releases`

Recommended GitHub description:

`Official LanGuard Pro releases, changelog, support and public documentation for OpenWrt / ImmortalWrt router management.`

Do not initialize it with another README if you plan to upload this package as-is.

After upload:

1. Enable Issues.
2. Set repository website to the Google Play listing once the listing is public.
3. Pin this repository on the SAMZLAB-PK profile.
4. Keep the development/source repository private.
5. Use GitHub Releases only for intentionally signed public binaries.
