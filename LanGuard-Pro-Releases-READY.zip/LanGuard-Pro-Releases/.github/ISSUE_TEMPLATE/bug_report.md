---
name: Bug report
about: Report a reproducible LanGuard Pro problem
title: "[Bug] "
labels: bug
assignees: ''
---

## LanGuard Pro version

Version name:
Version code:

## Android device

Device:
Android version:

## Router

Model:
Firmware / version:

## Area affected

- [ ] Android app
- [ ] Companion
- [ ] LuCI LanGuard Pro
- [ ] Live speed / usage
- [ ] Speed test
- [ ] SSH install / repair
- [ ] Other

## What happened?

Describe the problem clearly.

## Reproduction steps

1.
2.
3.

## Expected result

What should have happened?

## Sanitized logs / screenshots

Do **not** include router passwords, SSH private keys, Wi-Fi passwords, API tokens, or other secrets.
