---
name: Feature request
about: Suggest an improvement for LanGuard Pro
title: "[Feature] "
labels: enhancement
assignees: ''
---

## Problem / use case

What are you trying to do?

## Proposed improvement

Describe the behavior you would like.

## Router / Android context

Add any relevant router model, firmware, or Android version details.
