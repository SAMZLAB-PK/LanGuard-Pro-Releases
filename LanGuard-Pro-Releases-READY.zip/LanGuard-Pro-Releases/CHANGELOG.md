# Changelog

## 2.9.4 — 20905

### Reliability
- Fixed the SSH host-key repository path that could produce `NullPointerException: Attempt to get length of null array` during Companion or LuCI installation.
- Added guided **Reset SSH Trust & Retry** recovery for genuine SSH identity/trust failures.
- Preserved normal password/network error handling without unnecessary SSH-trust resets.

### Live monitoring
- Aligned Android Home and Devices foreground refresh cadence to approximately 2 seconds, matching the LuCI experience more closely.
- Added IPv4 + IPv6 neighbor discovery and traffic accounting for better live-speed coverage.
- Improved counter reset/rebuild handling so stale or ghost device speeds are not retained.

### Speed test
- Tuned the Cloudflare fallback to use bounded parallel streams rather than excessive concurrency.
- Router-native speed-test utilities remain preferred when available.

### LuCI
- Added public Google Play, privacy, and SAMZ Labs links to the LanGuard Pro page.
- Kept the UI focused on router management while making the Android app easier to discover.

### Android / Play Store readiness
- Version: `2.9.4`
- Version code: `20905`
- Target / compile SDK: API 36
- Android Gradle Plugin aligned to the API 36-compatible build line.
- Removed remaining API-26-incompatible `String.isBlank()` usage.

## 2.9.3 — 20904

- Hardened router credential storage using Android Keystore-backed encryption.
- Added SSH trust pinning / reset support.
- Improved Companion payload synchronization and release validation.
- Strengthened WebView/native bridge boundaries.
- Improved Tailscale background identity handling.
