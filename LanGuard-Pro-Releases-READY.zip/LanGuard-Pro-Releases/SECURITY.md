# Security policy

Please do not publish router credentials, SSH keys, authentication tokens, or other secrets in a public issue.

If you discover a vulnerability, describe the minimum information needed to reproduce it and avoid exposing third-party systems or credentials.

The public issue tracker should not be used to post live router passwords or private network secrets.
