<p align="center">
  <img src="assets/languard-pro-icon.png" width="128" alt="LanGuard Pro icon" />
</p>

<h1 align="center">LanGuard Pro</h1>

<p align="center">
  Professional router monitoring and control for OpenWrt / ImmortalWrt.
</p>

<p align="center">
  <a href="https://play.google.com/store/apps/details?id=com.samz.languardpro"><strong>Get it on Google Play</strong></a>
  ·
  <a href="https://github.com/SAMZLAB-PK/LanGuard-Pro-Privacy">Privacy Policy</a>
  ·
  <a href="https://github.com/SAMZLAB-PK">SAMZ Labs</a>
</p>

---

## Latest release

**LanGuard Pro 2.9.4** · Version code **20905**

- Android package: `com.samz.languardpro`
- Target / compile SDK: Android 16 / API 36
- Minimum Android: API 26
- Router support: OpenWrt / ImmortalWrt, including Xiaomi AX3200 / AX6S class devices

See the full notes in [`releases/v2.9.4.md`](releases/v2.9.4.md).

## What LanGuard Pro does

LanGuard Pro provides a mobile-friendly control surface for compatible OpenWrt / ImmortalWrt routers, with a native Android app and a LuCI companion interface.

Key capabilities include:

- Live device discovery and online/offline state
- Per-device real-time upload/download rates
- IPv4 + IPv6 traffic accounting
- Device block / unblock
- Per-device speed limits and priority controls
- Device rename and DHCP reservation workflows
- Router / WAN status and latency monitoring
- Router-side speed test with fallback measurement
- Ad-block service status and controls
- Background router monitoring and notifications
- Multi-router profiles such as Home and Office
- Tailscale peer visibility
- Companion and LuCI LanGuard Pro install / repair tools
- SSH trust protection with guided recovery after router firmware resets

## Download

### Google Play — recommended

Install and update LanGuard Pro from Google Play:

**https://play.google.com/store/apps/details?id=com.samz.languardpro**

Public APK files will only be attached to GitHub Releases when they are intentionally published and signed for public distribution. Do not install APKs from unofficial mirrors.

## Router installation

LanGuard Pro can install or repair its router Companion and LuCI components from the Android app using the saved router connection profile.

A router firmware reinstall or SSH host-key change may require **Reset SSH Trust** before reconnecting. LanGuard Pro 2.9.4 adds guided recovery for this case.

See [`docs/ROUTER-INSTALLATION.md`](docs/ROUTER-INSTALLATION.md).

## Privacy

Privacy information is maintained publicly here:

**https://github.com/SAMZLAB-PK/LanGuard-Pro-Privacy**

## Support

Use this public releases repository for bug reports and feature requests. Before opening an issue, please remove passwords, SSH keys, public IP addresses, serial numbers, and any other sensitive information.

See [`SUPPORT.md`](SUPPORT.md).

## Source code

The active LanGuard Pro development repository is maintained privately. This public repository is the official release, changelog, documentation, and support hub for LanGuard Pro.

## Developer

**SAMZ Labs**  
GitHub: https://github.com/SAMZLAB-PK

---

LanGuard Pro is an independent router management application and is not affiliated with the OpenWrt or ImmortalWrt projects.
