# Router installation and repair

LanGuard Pro supports compatible OpenWrt / ImmortalWrt routers through two router-side components:

1. **LanGuard Companion** — the canonical router service/API used by the Android app.
2. **LuCI LanGuard Pro** — the router web interface.

## Recommended workflow

1. Add or select the router in the Android app.
2. Confirm the router IP and login credentials.
3. Open **More**.
4. Use **Check service** before repair/update when diagnosing a problem.
5. Use **Repair / update** for the Companion component when needed.
6. Install or update **LuCI LanGuard Pro** from its own control.

## SSH trust warning

OpenWrt / ImmortalWrt firmware reinstalls can generate a new SSH host key. A previously trusted fingerprint will then no longer match.

LanGuard Pro 2.9.4 can offer **Reset SSH Trust & Retry** when the failure matches an SSH identity/trust problem.

Only reset SSH trust when you expect the router identity to have changed — for example after a firmware reinstall, factory reset, or deliberate SSH host-key regeneration.

## Never post credentials in support issues

Do not include:

- router root password
- SSH private keys
- Wi-Fi passwords
- public IP addresses unless absolutely required and intentionally disclosed
- screenshots containing secrets
